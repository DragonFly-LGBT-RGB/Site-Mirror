#!/bin/sh
cd "$(dirname "$0")" || exit 1
echo "site_mirror v1.4 — открываю веб-интерфейс..."
python3 site_mirror.py
