@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo site_mirror v1.4 - otkryvayu veb-interfeys...
python site_mirror.py
pause
